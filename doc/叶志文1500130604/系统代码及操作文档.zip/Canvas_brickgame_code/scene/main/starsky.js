var Starsky = function(game) {
    var o = game.imageByName('starsky')

    // var o = {
    //     image: image,
    //     x: 100,
    //     y: 250,
    //     speed: 15,
    // }
    o.x = 0
    o.y = 0

    return o
}
