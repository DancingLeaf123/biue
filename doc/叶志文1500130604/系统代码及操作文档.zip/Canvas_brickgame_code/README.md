# gua.game.js
JavaScript 写游戏
